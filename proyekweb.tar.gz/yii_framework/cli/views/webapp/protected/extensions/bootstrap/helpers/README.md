# TbHtml?! WTF?

This file exists here only for YiiBooster to be compatible with `yii-auth` extension which depends on Yiistrap's TbHtml.

See [Issue #443](https://github.com/clevertech/YiiBooster/issues/443) for details.

Yes, this is a nightmare and most possibly this class will be dropped in future.